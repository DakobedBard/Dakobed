package org.mddarr.dakobedorders;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DakobedOrdersApplication {

	public static void main(String[] args) {
		SpringApplication.run(DakobedOrdersApplication.class, args);
	}

}
