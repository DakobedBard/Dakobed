package org.mddarr.dakobedorders;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DakobedOrdersApplicationTests {

	@Test
	void contextLoads() {
	}

}
