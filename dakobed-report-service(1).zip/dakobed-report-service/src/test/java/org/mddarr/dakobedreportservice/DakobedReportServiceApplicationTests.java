package org.mddarr.dakobedreportservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DakobedReportServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
